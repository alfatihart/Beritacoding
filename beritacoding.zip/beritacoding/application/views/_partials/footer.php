<footer class="footer">
	&copy; <?= Date('Y') ?> Beritacoding.com
</footer>